title = "My Visual Novel"
author = "Oxycode"
start_game = "Start game"
back_to_menu = "Back to menu"
